﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Net;

namespace TelnetFileExplorer
{
    public static class TcpConnectionHelper
    {
        private const int CONNECT_TIMEOUT = 30000;
        private const int NO_DATA_TIMEOUT = 500;
        private const int BUFFER_SIZE = 32768;

        /// <summary>
        /// Returns all IPAddresses registered for this computer
        /// </summary>
        public static IPAddress[] GetLocalIPAddresses(bool internetOnly)
        {
            IPAddress[] all = Dns.GetHostEntry(Dns.GetHostName()).AddressList;

            return internetOnly ? all.ToList().FindAll(ip => ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork).ToArray() : all;
        }

        #region WaitForConnection & ConnectToClient

        /// <summary>
        /// Listens on a specified port 
        /// </summary>
        /// <param name="port">The TCP port to listen on</param>
        /// <param name="timeout">The wait-for-connection timeout in milliseconds</param>
        /// <returns>The connected client or null if none</returns>
        public static TcpClient WaitForConnection(int port, int timeout)
        {
            int maxNoDataCount = timeout / 100;

            // Wait for Connection
            TcpListener listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            int noDataCount = 0;
            while (!listener.Pending())
            {
                Thread.Sleep(100);
                noDataCount++;
                if (noDataCount > maxNoDataCount)
                {
                    listener.Stop();
                    return null;
                }
            }

            // Accept connection
            TcpClient client = listener.AcceptTcpClient(); // Get client
            if (!client.Client.Connected) return null;
            listener.Stop(); // No further connections

            // Data exchange
            return client;
        }

        /// <summary>
        /// Tries to connect to a server withing the given timeout
        /// </summary>
        /// <param name="addr">A server address to connect to</param>
        /// <param name="port">The server port to connect to</param>
        /// <param name="timeout">The timeout in milliseconds</param>
        /// <returns>The conneted Client or null if not connected within timeout</returns>
        public static TcpClient ConnectToClient(string addr, int port, int timeout)
        {
            TcpClient client = new TcpClient();
            bool connected = false;

            AsyncCallback callback = new AsyncCallback(result =>
            {
                try
                {
                    client.EndConnect(result);
                    connected = true;
                }
                catch { }
            });
            client.BeginConnect(addr, port, callback, null);

            DateTime timeBarrier = DateTime.Now.AddMilliseconds(timeout);
            while (!connected && DateTime.Now < timeBarrier) { Thread.Sleep(50); }

            if (connected)
                return client;
            else
            {
                try { client.Close(); }
                catch { }
                return null;
            }
        }

        #endregion


        #region ReceiveDataListening

        /// <summary>
        /// Waits for a connection and starts to receive data as soon as a connection is established
        /// </summary>
        /// <param name="port">The port to listen on</param>
        /// <param name="output">A writable stream to process received data</param>
        /// <returns>If false, no connection could be established within the timeout</returns>
        public static bool ReceiveDataListening(int port, Stream output)
        {
            TcpClient client = WaitForConnection(port, CONNECT_TIMEOUT);
            if (client == null) return false;

            ReadClientToEnd(client, output, NO_DATA_TIMEOUT);

            return true;
        }
        /// <summary>
        /// Waits for a connection and starts to receive data as soon as a connection is established
        /// </summary>
        /// <param name="port">The port to listen on</param>
        /// <param name="filename">The path of the file to store received data in</param>
        /// <returns>If false, no connection could be established within the timeout</returns>
        public static bool ReceiveDataListening(int port, string filename)
        {
            bool result;
            using (FileStream fs = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                result = ReceiveDataListening(port, fs);
            }
            return result;
        }
        /// <summary>
        /// Waits for a connection and starts to receive data as soon as a connection is established
        /// </summary>
        /// <param name="port">The port to listen on</param>
        /// <param name="filename">The path of the file to store received data in</param>
        /// <returns>The received data or null on no connection</returns>
        public static byte[] ReceiveDataListening(int port)
        {
            byte[] result = null;
            using (MemoryStream ms = new MemoryStream())
            {
                if (ReceiveDataListening(port, ms))
                    result = ms.ToArray();
            }
            return result;
        }

        #endregion

        #region SendDataListening

        /// <summary>
        /// Waits for a connection and starts to send data as soon as a connection is established
        /// </summary>
        /// <param name="port">The local port to listen on</param>
        /// <param name="input">A readable stream providing data to send</param>
        /// <returns>If false, the connection was not established</returns>
        public static bool SendDataListening(int port, Stream input)
        {
            TcpClient client = WaitForConnection(port, CONNECT_TIMEOUT);
            if (client == null) return false;

            WriteToClient(client, input);

            return true;
        }
        /// <summary>
        /// Waits for a connection and starts to send data as soon as a connection is established
        /// </summary>
        /// <param name="port">The local port to listen on</param>
        /// <param name="filename">The path to a file to send</param>
        /// <returns>If false, the connection was not established</returns>
        public static bool SendDataListening(int port, string filename)
        {
            bool result = false;
            using (FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                result = SendDataListening(port, fs);
            }
            return result;
        }
        /// <summary>
        /// Waits for a connection and starts to send data as soon as a connection is established
        /// </summary>
        /// <param name="port">The local port to listen on</param>
        /// <param name="data">Data to send</param>
        /// <returns>If false, the connection was not established</returns>
        public static bool SendDataListening(int port, byte[] data)
        {
            bool result = false;
            using (MemoryStream ms = new MemoryStream(data))
            {
                result = SendDataListening(port, ms);
            }
            return result;
        }

        #endregion

        #region ReceiveDataConnecting

        /// <summary>
        /// Connects to a server and starts to retrieve data as soon as connection was established
        /// </summary>
        /// <param name="addr">The server address</param>
        /// <param name="port">The server port</param>
        /// <param name="output">A writable stream to process received data</param>
        /// <returns>If false, the connection was not established</returns>
        public static bool ReceiveDataConnecting(string addr, int port, Stream output)
        {
            TcpClient client = ConnectToClient(addr, port, CONNECT_TIMEOUT);
            if (client == null) return false;

            ReadClientToEnd(client, output, NO_DATA_TIMEOUT);

            return true;
        }
        /// <summary>
        /// Connects to a server and starts to retrieve data as soon as connection was established
        /// </summary>
        /// <param name="addr">The server address</param>
        /// <param name="port">The server port</param>
        /// <param name="filename">The path to a file to write received data to</param>
        /// <returns>If false, the connection was not established</returns>
        public static bool ReceiveDataConnecting(string addr, int port, string filename)
        {
            bool result;
            using (FileStream fs = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                result = ReceiveDataConnecting(addr, port, fs);
            }
            return result;
        }
        /// <summary>
        /// Connects to a server and starts to retrieve data as soon as connection was established
        /// </summary>
        /// <param name="addr">The server address</param>
        /// <param name="port">The server port</param>
        /// <returns>The received data or null on no connection</returns>
        public static byte[] ReceiveDataConnecting(string addr, int port)
        {
            byte[] result = null;
            using (MemoryStream ms = new MemoryStream())
            {
                if (ReceiveDataConnecting(addr, port, ms))
                    result = ms.ToArray();
            }
            return result;
        }

        #endregion

        #region SendDataConnecting

        /// <summary>
        /// Connects to a server and starts to send data as soon as a connection is established
        /// </summary>
        /// <param name="addr">The server address</param>
        /// <param name="port">The server port</param>
        /// <param name="input">A readable stream providing data to send</param>
        /// <returns>If false, the connection was not established</returns>
        public static bool SendDataConnecting(string addr, int port, Stream input)
        {
            TcpClient client = ConnectToClient(addr, port, CONNECT_TIMEOUT);
            if (client == null) return false;

            WriteToClient(client, input);

            return true;
        }
        /// <summary>
        /// Connects to a server and starts to send data as soon as a connection is established
        /// </summary>
        /// <param name="addr">The server address</param>
        /// <param name="port">The server port</param>
        /// <param name="filename">The path to a file to send</param>
        /// <returns>If false, the connection was not established</returns>
        public static bool SendDataConnecting(string addr, int port, string filename)
        {
            bool result = false;
            using (FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                result = SendDataConnecting(addr, port, fs);
            }
            return result;
        }
        /// <summary>
        /// Connects to a server and starts to send data as soon as a connection is established
        /// </summary>
        /// <param name="addr">The server address</param>
        /// <param name="port">The server port</param>
        /// <param name="data">Data to send</param>
        /// <returns>If false, the connection was not established</returns>
        public static bool SendDataConnecting(string addr, int port, byte[] data)
        {
            bool result = false;
            using (MemoryStream ms = new MemoryStream(data))
            {
                result = SendDataConnecting(addr, port, ms);
            }
            return result;
        }

        #endregion


        #region Internal read from and write to client

        private static void ReadClientToEnd(TcpClient client, Stream output, int timeout)
        {
            NetworkStream ns = client.GetStream();

            int len;
            int maxNoDataCount = timeout / 50;
            int noDataCount = -30;
            byte[] buffer;
            while (client.Client.Connected)
            {
                // Look for data to receive
                if (ns.DataAvailable)
                {
                    buffer = new byte[BUFFER_SIZE];
                    try { len = ns.Read(buffer, 0, BUFFER_SIZE); }
                    catch { len = 0; }

                    output.Write(buffer, 0, len);

                    noDataCount = 0;
                }
                else
                    noDataCount++;

                if (noDataCount > maxNoDataCount) break;

                Thread.Sleep(50);
            }
            try { client.Close(); }
            catch { }
        }

        private static void WriteToClient(TcpClient client, Stream input)
        {
            try
            {
                NetworkStream ns = client.GetStream();

                int len;
                byte[] buffer = new byte[BUFFER_SIZE];
                // Copy the file data info the stream
                while (client.Client.Connected && (len = input.Read(buffer, 0, BUFFER_SIZE)) > 0)
                {
                    ns.Write(buffer, 0, len);
                }
                ns.Flush();
            }
            catch { }
            try { client.Close(); }
            catch { }
        }

        #endregion
    }
}
