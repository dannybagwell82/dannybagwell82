﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Drawing;

namespace TelnetFileExplorer
{
    public class TelnetFileInfo
    {
        public string Path { get; set; }
        public string Name { get; set; }
        public bool IsLink { get;set; }
        public TelnetFilePermission PermissionOwner { get; set; }
        public TelnetFilePermission PermissionGroup { get; set; }
        public TelnetFilePermission PermissionAll { get; set; }
        public string Owner { get; set; }
        public string Group { get; set; }
        public long Length { get; set; }
        public DateTime TimeStamp { get; set; }
        public string LinkTo { get; set; }

        public string FullPath { get { return this.Path + "/" + this.Name; } }
    }

    public class TelnetDirectoryInfo : TelnetFileInfo
    {
        public List<TelnetDirectoryInfo> SubDirectories { get; set; }
        public List<TelnetFileInfo> Files { get; set; }

        public TelnetDirectoryInfo() 
        {
            this.SubDirectories = new List<TelnetDirectoryInfo>();
            this.Files = new List<TelnetFileInfo>();
        }
        public TelnetDirectoryInfo(string path, string name) : this()
        {
            this.Path = path;
            this.Name = name;
        }

        #region Conversion helper

        protected static readonly Regex _rexFileLine = new Regex(@"^(?<kind>[-ld])(?<permOwner>[rwx-]{3})(?<permGroup>[rwx-]{3})(?<permAll>[rwx-]{3})\s+(?<nrOfLnkOrDir>[0-9]+)\s+(?<user>[^\s]+)\s+(?<group>[^\s]+)\s+(?<size>\d+)\s+(?<weekday>\w+)\s+(?<datetime>\w+\s+\d+\s+\d{2}:\d{2}:\d{2}\s+\d+)\s+(?<filename>[^/\s]+)( -> (?<link>.+))?$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        protected static TelnetFilePermission GetPermission(string data)
        {
            TelnetFilePermission result = TelnetFilePermission.None;

            if (data.Contains('r') || data.Contains('R'))
                result |= TelnetFilePermission.Read;
            if (data.Contains('w') || data.Contains('W'))
                result |= TelnetFilePermission.Write;
            if (data.Contains('x') || data.Contains('X'))
                result |= TelnetFilePermission.Execute;

            return result;
        }

        protected static readonly Regex _rexDateTime = new Regex(@"(?<mon>jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dez)\s+(?<day>\d+)\s+(?<hour>\d{2}):(?<min>\d{2}):(?<sec>\d{2})\s+(?<year>\d+)", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        protected static readonly List<string> _months = "jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dez".Split('|').ToList();
        protected static DateTime GetDateTime(string data)
        {
            Match m = _rexDateTime.Match(data);
            if (m == null || !m.Success) return DateTime.MinValue;

            int year = Convert.ToInt32(m.Groups["year"].Value);
            int mon = _months.IndexOf(m.Groups["mon"].Value.ToLower()) + 1;
            int day = Convert.ToInt32(m.Groups["day"].Value);
            int hour = Convert.ToInt32(m.Groups["hour"].Value);
            int min = Convert.ToInt32(m.Groups["min"].Value);
            int sec = Convert.ToInt32(m.Groups["sec"].Value);

            return new DateTime(year, mon, day, hour, min, sec);
        }

        #endregion

        #region LoadCompleteTree

        public static TelnetDirectoryInfo LoadCompleteTree(TelnetConnection conn, string rootPath, Action<string> onCurrPath)
        {
            TelnetDirectoryInfo root = new TelnetDirectoryInfo();

            rootPath = rootPath.Trim('/');
            int pos = rootPath.LastIndexOf('/');

            TelnetDirectoryInfo curr = null;
            Match m;
            string filename;

            conn.GetRecursiveFileList(rootPath, line =>
            {
                line = line.TrimStart('.');
                if (line.Length == 0) { }
                else if (line.Length > 1 && line[line.Length - 1] == ':')
                {
                    curr = GetOrCreateByPath(root, line.Substring(0, line.Length - 1));
                    if (onCurrPath != null)
                        onCurrPath(line.Substring(0, line.Length - 1));
                }
                else if (curr != null)
                {
                    m = _rexFileLine.Match(line);
                    if (m == null || !m.Success) return;

                    filename = m.Groups["filename"].Value;

                    if (filename.Equals(".") || filename.Equals("..")) return;

                    TelnetFileInfo info;
                    switch (m.Groups["kind"].Value.ToLower())
                    {
                        case "-": // File
                            info = new TelnetFileInfo();
                            break;
                        case "l": // Link
                            info = new TelnetFileInfo();
                            info.IsLink = true;
                            break;
                        case "d": // Directory
                            info = new TelnetDirectoryInfo();
                            break;
                        default:
                            return;
                    }

                    info.Path = (curr.Path + "/" + curr.Name).TrimEnd('/');
                    info.Name = filename;
                    info.PermissionOwner = GetPermission(m.Groups["permOwner"].Value);
                    info.PermissionGroup = GetPermission(m.Groups["permGroup"].Value);
                    info.PermissionAll = GetPermission(m.Groups["permAll"].Value);
                    info.Owner = m.Groups["user"].Value;
                    info.Group = m.Groups["group"].Value;
                    info.Length = Convert.ToInt64(m.Groups["size"].Value);
                    info.TimeStamp = GetDateTime(m.Groups["datetime"].Value);
                    info.LinkTo = m.Groups["link"].Value;
                    if (info.LinkTo.StartsWith("./"))
                        info.LinkTo = info.LinkTo.Substring(1);

                    if (info is TelnetDirectoryInfo)
                        curr.SubDirectories.Add((TelnetDirectoryInfo)info);
                    else
                        curr.Files.Add(info);
                }
            });

            return root;
        }

        private static TelnetDirectoryInfo GetOrCreateByPath(TelnetDirectoryInfo root, string path)
        {
            if (path.Equals(String.Empty) || path.Equals("/")) return root;
            string[] parts = path.Trim('/').Split('/');
            string currPath = String.Empty;
            TelnetDirectoryInfo curr = root;
            TelnetDirectoryInfo info;
            foreach (string subDir in parts)
            {
                info = curr.SubDirectories.FirstOrDefault(i => i.Name.Equals(subDir));
                if (info == null)
                {
                    info = new TelnetDirectoryInfo(currPath, subDir);
                    curr.SubDirectories.Add(info);
                }
                curr = info;
                currPath += "/" + subDir;
            }
            return curr;
        }

        #endregion
    }

    [Flags]
    public enum TelnetFilePermission
    {
        None = 0,
        Read = 1,
        Write = 2,
        Execute = 4
    }
}
