﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Threading;
using System.IO;

namespace TelnetFileExplorer
{
    public partial class MainForm : Form
    {
        private const string START_PATH = "/";

        private TelnetConnection _currConnection = null;

        public MainForm()
        {
            InitializeComponent();

            optDownloadMethod.SelectedIndex = 0;
        }

        #region Event handling

        // Handle [Enter] key in Password TextBox
        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar == 0x0D)
            {
                e.Handled = true;
                btnConnect_Click(this, new EventArgs());
            }
        }

        // Connect to the server
        private void btnConnect_Click(object sender, EventArgs e)
        {
            int port = 23;
            string addr = txtServer.Text;

            int pos = addr.LastIndexOf(':');
            if (pos != -1 && pos < addr.Length - 1)
            {
                try { port = Convert.ToUInt16(addr.Substring(pos + 1)); }
                catch { pos = -1; }
            }
            if (pos != -1) addr = addr.Substring(0, pos);

            if (_currConnection != null)
                _currConnection.Dispose();

            StatusForm pro = new StatusForm("Loading Directory", "Connectiong to server...", false, false);
            pro.Show();
            Thread.Sleep(50);
            Application.DoEvents();

            TelnetConnection conn = new TelnetConnection(addr, port, txtPassword.Text, txtUsername.Text);
            _currConnection = conn;
            conn.Connect();

            ReloadDirectoryTree(pro);
        }

        // After an entry in the tree is selected, show information in the ListView
        private void lstFilelist_AfterSelect(object sender, TreeViewEventArgs e)
        {
            SuspendLayout();

            lstInfo.Items.Clear();
            TelnetFileInfo info = e.Node.Tag as TelnetFileInfo;
            if (info != null)
            {
                lstInfo.Items.Add(new ListViewItem(new[] { "Path", info.Path }));
                lstInfo.Items.Add(new ListViewItem(new[] { "Name", info.Name }));
                if (!(info is TelnetDirectoryInfo))
                    lstInfo.Items.Add(new ListViewItem(new[] { "Size", info.Length.ToString("###.###.###.###") }));
                lstInfo.Items.Add(new ListViewItem(new[] { "LastModified", info.TimeStamp.ToString("yyyy-MM-dd HH:mm:dd") }));
                lstInfo.Items.Add(new ListViewItem(new[] { "IsLink", info.IsLink.ToString() }));
                if (info.IsLink)
                    lstInfo.Items.Add(new ListViewItem(new[] { "Links to", info.LinkTo }));
                lstInfo.Items.Add(new ListViewItem(new[] { "Permission Owner", info.PermissionOwner.ToString() }));
                lstInfo.Items.Add(new ListViewItem(new[] { "Permission Group", info.PermissionGroup.ToString() }));
                lstInfo.Items.Add(new ListViewItem(new[] { "Permission All", info.PermissionAll.ToString() }));
                lstInfo.Items.Add(new ListViewItem(new[] { "Owner", info.Owner }));
                lstInfo.Items.Add(new ListViewItem(new[] { "Group", info.Group }));

                if (info is TelnetDirectoryInfo)
                {
                    lstInfo.Items.Add(new ListViewItem(new[] { "SubDirectories", (info as TelnetDirectoryInfo).SubDirectories.Count.ToString() }));
                    lstInfo.Items.Add(new ListViewItem(new[] { "Files", (info as TelnetDirectoryInfo).Files.Count.ToString() }));
                }
            }

            ResumeLayout();
        }

        // When an entry is double-clicked and is a link, try to jump to the link target
        private void lstFilelist_DoubleClick(object sender, EventArgs e)
        {
            TreeNode node = lstFilelist.SelectedNode;
            if (node == null) return;
            TelnetFileInfo info = node.Tag as TelnetFileInfo;
            if (info == null || !info.IsLink) return;

            TreeNode target = SearchTreeNodeByPath(info.LinkTo);
            if (target != null)
                lstFilelist.SelectedNode = target;
        }

        // Download a file or directory tree
        private void btnDownload_Click(object sender, EventArgs e)
        {
            if (_currConnection == null) return;
            TreeNode node = lstFilelist.SelectedNode;
            if (node == null) return;
            TelnetFileInfo info = node.Tag as TelnetFileInfo;
            if (info == null) return;

            int method = optDownloadMethod.SelectedIndex;

            int port = -1;
            try { port = Convert.ToInt32(txtDownloadPort.Text); }
            catch { return; }

            if (info is TelnetDirectoryInfo)
            {
                FolderBrowserDialog d = new FolderBrowserDialog();
                d.ShowNewFolderButton = true;
                d.Description = "Please select a path to store the content of this directory in.";
                if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    bool cancel = false;
                    bool running = true;
                    StatusForm pro = new StatusForm("Directory download", "Starting download...", false, true);
                    pro.CancelClicked += (a1, a2) => cancel = true;
                    pro.Show();

                    (new Thread(new ThreadStart(() =>
                    {
                        SaveAllFiles(info as TelnetDirectoryInfo, d.SelectedPath, port, method,   
                            currFile => pro.SetText(String.Format("Current file: {0}", currFile)), 
                            () => !cancel);

                        pro.Invoke(new Action(() => pro.Close()));
                    }))
                    {
                        IsBackground = true,
                        Priority = ThreadPriority.Normal
                    }).Start();

                    while (running)
                    {
                        Thread.Sleep(100);
                        Application.DoEvents();
                    }
                }
            }
            else
            {
                SaveFileDialog d = new SaveFileDialog();
                d.FileName = info.Name;
                if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    DownloadFile(info.Path + "/" + info.Name, d.FileName, port, method);
                }
            }
        }

        // Upload a file or files - directory upload is not implemented
        private void btnUpload_Click(object sender, EventArgs e)
        {
            int port = -1;
            try { port = Convert.ToInt32(txtDownloadPort.Text); }
            catch { return; }

            TelnetDirectoryInfo info = lstFilelist.SelectedNode == null ? null : lstFilelist.SelectedNode.Tag as TelnetDirectoryInfo;
            if (info == null)
            {
                MessageBox.Show("Please select a directory to upload a file to first!");
                return;
            }
            string uploadPath = info.Path + "/" + info.Name + "/";

            int method = optDownloadMethod.SelectedIndex;

            OpenFileDialog d = new OpenFileDialog();
            string name;
            d.Multiselect = true;
            if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                foreach (string filename in d.FileNames)
                {
                    name = Path.GetFileName(filename);
                    UploadFile(filename, uploadPath + name, port, method);
                }
            }
        }

        // Delete a file or directory tree and reload directory tree aferwards
        private void btnDelete_Click(object sender, EventArgs e)
        {
            TelnetFileInfo info = lstFilelist.SelectedNode == null ? null : lstFilelist.SelectedNode.Tag as TelnetFileInfo;
            if (info == null)
            {
                MessageBox.Show("Please select a file or directory to delete first!");
                return;
            }
            string remotePath = info.FullPath;

            if (MessageBox.Show(String.Format("Do you really want to delete the selected {1}: \r\n{0}", remotePath, 
                info is TelnetDirectoryInfo ? "directory tree" : "file"), "Confirm delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) 
                != System.Windows.Forms.DialogResult.Yes) return;

            _currConnection.Delete(remotePath, info is TelnetDirectoryInfo);

            ReloadDirectoryTree(null);
        }

        // Create a new folder, prefill input field if directory is selected, then reload directory tree
        private void btnNewFolder_Click(object sender, EventArgs e)
        {
            TelnetFileInfo info = lstFilelist.SelectedNode == null ? null : lstFilelist.SelectedNode.Tag as TelnetDirectoryInfo;
            string remotePath = info == null ? String.Empty : info.FullPath;
            if (remotePath.Equals("/")) remotePath = String.Empty;

            TextInputDialog d = new TextInputDialog("Create New Directory", "Please enter the full path of the new directory:", remotePath + "/new_folder");
            d.SetSelection(remotePath.Length + 1, 10);
            if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string value = d.InputValue;
                if (value.EndsWith("/")) value = value.Substring(0, value.Length - 1);
                _currConnection.CreateDirectory(d.InputValue);

                ReloadDirectoryTree(null);
            }
        }

        // Update port input field visibility and description
        private void optDownloadMethod_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblDownloadPort.Visible = txtDownloadPort.Visible = (optDownloadMethod.SelectedIndex < 2);
            if (optDownloadMethod.SelectedIndex == 0) lblDownloadPort.Text = "Remote Port:";
            else if (optDownloadMethod.SelectedIndex == 1) lblDownloadPort.Text = "Local Port:";
        }

        #endregion

        #region Helpers

        private void SaveAllFiles(TelnetDirectoryInfo dir, string folder, int localPort, int method, Action<string> onCurrFile, Func<bool> goOn)
        {
            if (!folder.EndsWith("\\")) folder += "\\";

            string filename;
            foreach (TelnetFileInfo file in dir.Files)
            {
                if (file.IsLink) continue;
                filename = file.Path + "/" + file.Name;
                if (onCurrFile != null) onCurrFile(filename);
                if (!File.Exists(folder + file.Name))
                {
                    DownloadFile(filename, folder + file.Name, localPort, method);
                    Thread.Sleep(50);
                }
                if (!goOn()) return;
            }

            foreach (TelnetDirectoryInfo sDir in dir.SubDirectories)
            {
                filename = folder + sDir.Name;
                if (!Directory.Exists(filename))
                    Directory.CreateDirectory(filename);
                SaveAllFiles(sDir, filename, localPort, method, onCurrFile, goOn);
                if (!goOn()) return;
            }
        }

        private void DownloadFile(string remotePath, string localPath, int port, int method)
        {
            switch (method)
            {
                case 0: // netcat client->server
                    _currConnection.DownloadFileActive(remotePath, localPath, port);
                    break;

                case 1: // netcat client<-server
                    _currConnection.DownloadFilePassive(remotePath, localPath, null, port);
                    break;

                case 2: // cat
                    _currConnection.DownloadFileCat(remotePath, localPath);
                    break;

                default:
                    break;
            }
        }

        private void UploadFile(string localPath, string remotePath, int port, int method)
        {
            switch (method)
            {
                case 0: // netcat client->server
                    _currConnection.UploadFileActive(localPath, remotePath, port);
                    break;

                case 1: // netcat client<-server
                    _currConnection.UploadFilePassive(localPath, remotePath, null, port);
                    break;

                case 2: // echo
                    _currConnection.UploadFileEcho(localPath, remotePath);
                    break;

                default:
                    break;
            }
        }

        public TreeNode ConvertTelnetDirectoryToTreeNode(TelnetDirectoryInfo curr)
        {
            TreeNode node = new TreeNode("[" + curr.Name + "]") 
            { 
                Tag = curr, 
                ForeColor = Color.Red, 
                ImageIndex = 0,
                SelectedImageIndex = 0
            };

            curr.SubDirectories.ForEach(s => node.Nodes.Add(ConvertTelnetDirectoryToTreeNode(s)));

            curr.Files.ForEach(f => 
            { 
                TreeNode fNode = new TreeNode(f.Name)
                {
                    Tag = f,
                    ForeColor = f.IsLink ? Color.Blue : Color.Black,
                    ImageIndex = f.IsLink ? 2 : 1,
                    SelectedImageIndex = f.IsLink ? 2 : 1
                };
                node.Nodes.Add(fNode);
            });

            return node;
        }
        
        private TreeNode SearchTreeNodeByPath(string path)
        {
            if (lstFilelist.Nodes.Count == 0) return null;
            string[] paths = path.TrimStart('/').Split('/');
            return SearchTreeNodeByPath(paths, lstFilelist.Nodes[0]);
        }
        private TreeNode SearchTreeNodeByPath(string[] path, TreeNode root)
        {
            TelnetDirectoryInfo info = root.Tag as TelnetDirectoryInfo;
            if (info == null) return null;

            if (path.Length == 0)
                return root;
            else if (path.Length == 1)
            {
                TelnetFileInfo fi;
                foreach (TreeNode node in root.Nodes)
                {
                    fi = node.Tag as TelnetFileInfo;
                    if (fi == null) continue;
                    if (fi.Name.Equals(path[0])) return node;
                }
            }
            else
            {
                TelnetDirectoryInfo di;
                foreach (TreeNode node in root.Nodes)
                {
                    di = node.Tag as TelnetDirectoryInfo;
                    if (di == null) continue;
                    if (di.Name.Equals(path[0]))
                    {
                        node.Expand();
                        TreeNode result = SearchTreeNodeByPath(path.Skip(1).ToArray(), node);
                        if (result != null) return result;
                    }
                }
            }

            return null;
        }

        private void ReloadDirectoryTree(StatusForm pro)
        {
            if (pro == null)
            {
                pro = new StatusForm("Reloading...", "Reloading directory tree...", false, false);
                pro.Show();
            }

            lstFilelist.Nodes.Clear();

            pro.SetText("Directory listing started...");
            (new Thread(new ThreadStart(() =>
            {
                TelnetDirectoryInfo dirs = TelnetDirectoryInfo.LoadCompleteTree(_currConnection, START_PATH, currDir =>
                {
                    pro.SetText("Current Directory:\r\n" + currDir);
                });
                pro.SetText("Prepare tree view...");
                //TreeNode root = dirs.GetTreeNode();
                TreeNode root = ConvertTelnetDirectoryToTreeNode(dirs);

                this.Invoke(new Action(() =>
                {
                    root.Text = String.Format("{0}:{1}", _currConnection.Address, _currConnection.Port);
                    this.Text = String.Format("Telnet File Explorer [{0}:{1}]", _currConnection.Address, _currConnection.Port);
                    lstFilelist.Nodes.Add(root);
                    root.Expand();
                }));
                pro.Invoke(new Action(() => pro.Close()));
            }))
            {
                IsBackground = true,
                Priority = ThreadPriority.Normal
            }).Start();
        }

        #endregion

        protected override void OnClosed(EventArgs e)
        {
            if (_currConnection != null)
                _currConnection.Dispose();
            _currConnection = null;

            base.OnClosed(e);
        }

    }
}
