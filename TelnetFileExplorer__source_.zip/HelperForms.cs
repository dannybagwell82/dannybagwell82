﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace TelnetFileExplorer
{
    public class StatusForm : Form
    {
        private Label lblText;
        private Button btnCancel;
        private ProgressBar proProgress;

        public StatusForm(string title, string text, bool showProgressBar, bool cancelButtonEnabled)
        {
            SuspendLayout();

            this.Text = title;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.ControlBox = false;
            this.Width = 320;
            this.Height = 200;
            this.TopMost = true;

            Panel p = new Panel();
            this.Controls.Add(p);
            p.Dock = DockStyle.Fill;

            lblText = new Label();
            p.Controls.Add(lblText);
            lblText.Top = 0;
            lblText.Left = 0;
            lblText.Width = p.Width;
            lblText.Height = p.Height - 32;
            lblText.Text = text;
            lblText.Font = new System.Drawing.Font(FontFamily.GenericSansSerif, 10f, FontStyle.Bold);
            lblText.TextAlign = ContentAlignment.MiddleCenter;
            lblText.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;

            btnCancel = new Button();
            p.Controls.Add(btnCancel);
            btnCancel.Top = p.Height - 32;
            btnCancel.Left = p.Width - 100;
            btnCancel.Width = 100;
            btnCancel.Height = 32;
            btnCancel.Text = "Cancel";
            btnCancel.Font = new System.Drawing.Font(FontFamily.GenericSansSerif, 10f, FontStyle.Bold);
            btnCancel.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            btnCancel.Click += new EventHandler(btnCancel_Click);
            btnCancel.Enabled = cancelButtonEnabled;

            proProgress = new ProgressBar();
            p.Controls.Add(proProgress);
            proProgress.Top = p.Height - 32;
            proProgress.Left = 0;
            proProgress.Width = btnCancel.Left - 3;
            proProgress.Height = 32;
            proProgress.Minimum = 0;
            proProgress.Maximum = 1000;
            proProgress.Value = 0;
            proProgress.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            proProgress.Visible = showProgressBar;

            ResumeLayout();
        }

        void btnCancel_Click(object sender, EventArgs e)
        {
            if (CancelClicked != null) CancelClicked(this, new EventArgs());
        }

        public event EventHandler CancelClicked;

        public void SetText(string text)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action<string>(SetText), text);
                return;
            }

            lblText.Text = text;
        }

        private void SetProgress(double percent)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action<double>(SetProgress), percent);
                return;
            }

            int value = Math.Min(Math.Max(Convert.ToInt32(percent * 10.0), 0), 1000);
            proProgress.Value = value;
        }
    }

    public class TextInputDialog : Form
    {
        private Label lblInfo;
        private TextBox txtInput;
        private Button btnOk;
        private Button btnCancel;

        public TextInputDialog(string title, string info, string prefilledValue)
        {
            SuspendLayout();

            this.Width = 320;
            this.Height = 150;
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.ControlBox = false;

            Panel main = new Panel();
            this.Controls.Add(main);
            main.Dock = DockStyle.Fill;

            lblInfo = new Label();
            main.Controls.Add(lblInfo);
            lblInfo.Left = 0;
            lblInfo.Top = 0;
            lblInfo.Width = main.Width;
            lblInfo.Height = main.Height - 60;
            lblInfo.Font = new Font(FontFamily.GenericSansSerif, 10f, FontStyle.Bold);
            lblInfo.Text = info;
            lblInfo.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom;

            txtInput = new TextBox();
            main.Controls.Add(txtInput);
            txtInput.Top = main.Height - 60;
            txtInput.Left = 0;
            txtInput.Width = main.Width;
            txtInput.Text = prefilledValue;
            txtInput.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

            btnOk = new Button();
            main.Controls.Add(btnOk);
            btnOk.Left = main.Width - 75;
            btnOk.Top = main.Height - 35;
            btnOk.Width = 75;
            btnOk.Height = 35;
            btnOk.Font = new Font(FontFamily.GenericSansSerif, 10f, FontStyle.Bold);
            btnOk.Text = "OK";
            btnOk.Tag = DialogResult.OK;
            btnOk.Click += btn_Click;
            btnOk.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;

            btnCancel = new Button();
            main.Controls.Add(btnCancel);
            btnCancel.Left = btnOk.Left - 78;
            btnCancel.Top = main.Height - 35;
            btnCancel.Width = 75;
            btnCancel.Height = 35;
            btnCancel.Font = new Font(FontFamily.GenericSansSerif, 10f, FontStyle.Bold);
            btnCancel.Text = "Cancel";
            btnCancel.Tag = DialogResult.Cancel;
            btnCancel.Click += btn_Click;
            btnCancel.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;

            ResumeLayout();
        }

        private void btn_Click(object sender, EventArgs e)
        {
            DialogResult = (DialogResult)(sender as Control).Tag;
        }

        public string InputValue
        {
            get { return txtInput.Text; }
            set
            {
                if (this.InvokeRequired)
                    this.Invoke(new Action(() => txtInput.Text = value));
                else
                    txtInput.Text = value;
            }
        }

        public void SetSelection(int start, int length)
        {
            if (this.InvokeRequired)
                this.Invoke(new Action(() =>
                {
                    txtInput.SelectionStart = start;
                    txtInput.SelectionLength = length;
                }));
            else
            {
                txtInput.SelectionStart = start;
                txtInput.SelectionLength = length;
            }
        }
    }
}
