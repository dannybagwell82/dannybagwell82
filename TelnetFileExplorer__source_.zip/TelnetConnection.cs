﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Net;

namespace TelnetFileExplorer
{
    public class TelnetConnection : IDisposable
    {
        private const string COMMAND_ENTER = "\r\n";
        private const int BUFFER_SIZE = 32768;

        private TcpClient _client;
        private string _username;
        private string _password;
        private string _address;
        private int _port;
        private NetworkStream _stream;

        public TelnetConnection(string serverAddress, string password) : this(serverAddress, 23, password, String.Empty) { }
        public TelnetConnection(string serverAddress, int port, string password) : this(serverAddress, port, password, String.Empty) { }
        public TelnetConnection(string serverAddress, int port, string password, string username)
        {
            _address = serverAddress;
            _port = port;
            _username = username;
            _password = password;

            _client = new TcpClient();
        }

        private Thread _conn_Thread;
        private volatile bool _conn_keepRunning = true;
        private volatile bool _conn_Running = false;
        private volatile bool _conn_PushAllData = false;
        private volatile int _conn_Timeout = 20;
        private List<byte> _conn_SendData;
        private object _conn_Lock = new object();
        private void ConnectionThread()
        {
            _conn_Running = true;

            _conn_SendData = new List<byte>();
            try
            {
                _client = new TcpClient();
                _client.Connect(_address, _port);
                _stream = _client.GetStream();
            }
            catch
            {
                _conn_keepRunning = false;
            }

            byte[] buffer = new byte[BUFFER_SIZE]; // 8KB
            int len, pos, start, noDataCount = 0;
            string data = String.Empty;
            bool dataReceived = false;
            while (_conn_keepRunning && _client.Connected)
            {
                #region Receive data
                dataReceived = false;
                while (_stream.DataAvailable && (len = _stream.Read(buffer, 0, BUFFER_SIZE)) > 0)
                {
                    if (_conn_PushAllData)
                    {
                        CurrentRawDataHandler(buffer.Take(len));
                    }
                    else
                    {
                        data += Encoding.ASCII.GetString(buffer, 0, len);

                        #region Extract lines
                        pos = 0;
                        start = 0;
                        while ((pos = data.IndexOfAny(new[] { '\r', '\n' }, start)) != -1)
                        {
                            CurrentLineHandler(data.Substring(start, pos - start));
                            start = pos + 1;
                            // Skip next char \n if current was \r to handle Windows \r\n newline combination
                            if (data.Length > start && data[start - 1] == '\r' && data[start] == '\n') start++;
                        }
                        if (start != 0) data = data.Substring(start);
                        #endregion
                    }
                    dataReceived = true;
                }
                #region Bash hash timeout
                // When the remote is done with a command output, it ends with a hash '#' prompt
                // so let the handler know the last command is done.
                if (!dataReceived) noDataCount++;
                if (noDataCount > _conn_Timeout)
                {
                    if (data.Length != 0)
                    {
                        CurrentLineHandler(data);
                        CurrentTimeoutHandler();
                        data = String.Empty;
                    }
                    if (_conn_PushAllData)
                        CurrentTimeoutHandler();
                    noDataCount = 0;
                }
                #endregion
                #endregion

                #region Send data
                if (_conn_SendData.Count != 0)
                {
                    lock (_conn_Lock)
                    {
                        _stream.Write(_conn_SendData.ToArray(), 0, _conn_SendData.Count);
                        _conn_SendData.Clear();
                    }
                }
                #endregion

                // There is nothing more to do - let's save some recources and wait a bit before the next go
                Thread.Sleep(50);
            }
            try { _client.Close(); }
            catch { }
            _client = null;

            _conn_Running = false;
        }
        private void StartConnectionThread()
        {
            if (_conn_Running) return;

            _conn_keepRunning = true;
            _conn_Thread = new Thread(new ThreadStart(ConnectionThread))
            {
                IsBackground = true,
                Priority = ThreadPriority.Normal
            };
            _conn_Thread.Start();
        }
        private void StopConnectionThread()
        {
            if (!_conn_Running) return;

            _conn_keepRunning = false;
            while (_conn_Running) { Thread.Sleep(100); }
        }

        private void AddSendData(byte[] data)
        {
            lock (_conn_Lock)
            {
                _conn_SendData.AddRange(data);
            }
        }
        private void AddSendData(string data)
        {
            lock (_conn_Lock)
            {
                _conn_SendData.AddRange(Encoding.ASCII.GetBytes(data));
            }
        }

        private static readonly Action<string> DummyLineHandler = s => { };
        private static readonly Action<IEnumerable<byte>> DummyRawDataHandler = s => { };
        private static readonly Action DummyTimeoutHandler = () => { };

        private Action<string> CurrentLineHandler = DummyLineHandler;
        private Action<IEnumerable<byte>> CurrentRawDataHandler = DummyRawDataHandler;
        private Action CurrentTimeoutHandler = DummyTimeoutHandler;

        private void ResetConnHandlers()
        {
            CurrentLineHandler = DummyLineHandler;
            CurrentRawDataHandler = DummyRawDataHandler;
            CurrentTimeoutHandler = DummyTimeoutHandler;
            _conn_Timeout = 20;
            _conn_PushAllData = false;
        }

        public void Connect()
        {
            if (_conn_Running) return;

            bool loggedIn = false;
            _conn_Timeout = 3;
            CurrentLineHandler = line => 
            {
                _conn_Timeout = 20;
                if (line.ToLower().Contains("username:") || line.ToLower().Contains("login:"))
                    AddSendData(_username + COMMAND_ENTER);
                else if (line.ToLower().Contains("password:"))
                    AddSendData(_password + COMMAND_ENTER);
                else if (line.Length != 0 && line[0] == '#')
                    loggedIn = true;
            };

            StartConnectionThread();

            while (!loggedIn) { Thread.Sleep(100); }

            CurrentLineHandler = DummyLineHandler;
            CurrentTimeoutHandler = DummyTimeoutHandler;
        }

        public string Address { get { return _address; } }
        public int Port { get { return _port; } }

        public string SendCommand(string cmd, int timeout)
        {
            string result = String.Empty;
            bool working = true;

            Connect();

            _conn_Timeout = timeout / 50;
            CurrentLineHandler = line =>
            {
                if (!line.StartsWith(cmd))
                    result += line + COMMAND_ENTER;
                CurrentLineHandler = l => result += l + COMMAND_ENTER;
            };
            CurrentTimeoutHandler = () => working = false;

            AddSendData(cmd + COMMAND_ENTER);

            while (working) { Thread.Sleep(100); }

            ResetConnHandlers();

            return result;
        }

        /// <summary>
        /// Starts a recursive ls command on the remote system
        /// </summary>
        /// <param name="rootPath">The remote path to start from</param>
        /// <param name="onNewLine">A parser processing the output line by line</param>
        public void GetRecursiveFileList(string rootPath, Action<string> onNewLine)
        {
            string cmd = String.Format("ls -e -l -R {0}", rootPath);

            bool done = false;
            CurrentLineHandler = line =>
            {
                if (!line.StartsWith(cmd)) onNewLine(line);
                CurrentLineHandler = onNewLine;
            };
            CurrentTimeoutHandler = () => done = true;

            AddSendData(cmd + COMMAND_ENTER);
            
            while (!done) { Thread.Sleep(100); }

            ResetConnHandlers();
        }

        #region DownloadFile

        /// <summary>
        /// Downloads a remote file using nc command on the remote system to connect to local computer
        /// </summary>
        /// <param name="remotePath">The remote file to download</param>
        /// <param name="localPath">The local file to save the data into</param>
        /// <param name="localAddr">The address this computer is reachable at from the remote server - if null it is tried to detect the local IP</param>
        /// <param name="localPort">The local Port to use for incomming connection</param>
        public void DownloadFilePassive(string remotePath, string localPath, string localAddr, int localPort)
        {
            Connect();

            if (String.IsNullOrEmpty(localAddr))
            {
                IPAddress[] ips = TcpConnectionHelper.GetLocalIPAddresses(true);
                localAddr = ips.Length != 0 ? ips[0].ToString() : String.Empty;
            }

            string cmd = String.Format("nc {0} {1} < {2}", localAddr, localPort, remotePath);

            AddSendData(cmd + COMMAND_ENTER);

            TcpConnectionHelper.ReceiveDataListening(localPort, localPath);
        }

        /// <summary>
        /// Downloads a remote file using nc command on the remote system to wait for a conection from local computer
        /// </summary>
        /// <param name="remotePath">The remote file to download</param>
        /// <param name="localPath">The local file to save the data into</param>
        /// <param name="serverPort">The remote server port to connect to</param>
        public void DownloadFileActive(string remotePath, string localPath, int serverPort)
        {
            Connect();

            string cmd = String.Format("nc -l -p {0} < {1}", serverPort, remotePath);

            AddSendData(cmd + COMMAND_ENTER);

            TcpConnectionHelper.ReceiveDataConnecting(this._address, serverPort, localPath);
        }

        /// <summary>
        /// Downloads a remote file using cat command and reading the output - this could result in currupt files if used on binary types
        /// </summary>
        /// <param name="remotePath">The remote file to download</param>
        /// <param name="localPath">The local file to save the data into</param>
        public void DownloadFileCat(string remotePath, string localPath)
        {
            Connect();

            _conn_PushAllData = true;
            _conn_Timeout = 30;
            bool working = true;
            List<byte> buffer = new List<byte>();
            CurrentRawDataHandler = b => buffer.AddRange(b);
            CurrentTimeoutHandler = () => working = false;

            byte[] cmd = Encoding.ASCII.GetBytes("cat " + remotePath + COMMAND_ENTER);
            AddSendData(cmd);

            while (working) { Thread.Sleep(100); }

            ResetConnHandlers();

            if (buffer.Count > cmd.Length + 4)
            {
                using (FileStream o = new FileStream(localPath, FileMode.Create, FileAccess.Write, FileShare.None))
                    o.Write(buffer.ToArray(), cmd.Length, buffer.Count - (4 + cmd.Length));
            }
        }

        #endregion

        #region UploadFile

        /// <summary>
        /// Uploads a local file using NC command on the remote system to connect to local computer
        /// </summary>
        /// <param name="localPath">The local file to send</param>
        /// <param name="remotePath">The remote file to store data in</param>
        /// <param name="localAddr">The address this computer is reachable at from the remote server - if null it is tried to detect the local IP</param>
        /// <param name="localPort">The local Port to use for incomming connection</param>
        public bool UploadFilePassive(string localPath, string remotePath, string localAddr, int localPort)
        {
            Connect();

            if (String.IsNullOrEmpty(localAddr))
            {
                IPAddress[] ips = TcpConnectionHelper.GetLocalIPAddresses(true);
                localAddr = ips.Length != 0 ? ips[0].ToString() : String.Empty;
            }

            string cmd = String.Format("nc {0} {1} > {2}", localAddr, localPort, remotePath);

            AddSendData(cmd + COMMAND_ENTER);

            return TcpConnectionHelper.SendDataListening(localPort, localPath);
        }

        /// <summary>
        /// Uploads a local file using NC command on the remote system to wait for a conection from local computer
        /// </summary>
        /// <param name="localPath">The local file to send</param>
        /// <param name="remotePath">The remote file to store data to</param>
        /// <param name="serverPort">The remote server port to connect to</param>
        public bool UploadFileActive(string localPath, string remotePath, int serverPort)
        {
            Connect();

            string cmd = String.Format("nc -l -p {0} > {1}", serverPort, remotePath);

            AddSendData(cmd + COMMAND_ENTER);

            return TcpConnectionHelper.SendDataConnecting(this._address, serverPort, localPath);
        }

        /// <summary>
        /// Uploads a local file line by line to the server using ECHO command on the remote server which is directed into the remote file
        /// </summary>
        /// <param name="localPath">The local file to send</param>
        /// <param name="remotePath">The remote file to store data to</param>
        public bool UploadFileEcho(string localPath, string remotePath)
        {
            bool first = true;
            byte[] buffer = new byte[BUFFER_SIZE];
            int len;
            StringBuilder part = new StringBuilder();
            try
            {
                using (FileStream fs = new FileStream(localPath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    while ((len = fs.Read(buffer, 0, BUFFER_SIZE)) > 0)
                    {
                        byte b;
                        for (int i = 0; i < len; i++)
                        {
                            b = buffer[i];
                            if (b == 0x00) continue;
                            else if (b < 0x20 || b > 0x7F) part.Append("\\" + Convert.ToString(b, 8));
                            else if (b == 0x37) part.Append("\\'");
                            else if (b == 0x5C) part.Append("\\\\");
                            else part.Append((char)b);

                            if (part.Length > 999)
                            {
                                AddSendData(String.Format("echo -n $'{0}' {1} {2}", part.ToString(), first ? ">" : ">>", remotePath));
                                part = new StringBuilder();
                                first = false;
                            }
                        }
                    }
                    if (part.Length != 0)
                        AddSendData(String.Format("echo -n $'{0}' {1} {2}", part.ToString(), first ? ">" : ">>", remotePath));
                }
            }
            catch { return false; }

            return true;
        }

        #endregion

        /// <summary>
        /// Deletes a file or diretory tree using rm command
        /// </summary>
        /// <param name="remotePath">The full path of the file or directory tree to delete</param>
        /// <param name="isDirectory">If true, the -r option is used to delete recursively</param>
        public void Delete(string remotePath, bool isDirectory)
        {
            Connect();

            bool working = true;
            CurrentTimeoutHandler = () => working = false;

            string cmd = String.Format("rm -f{0} -- {1}{2}", isDirectory ? " -r" : "", remotePath, COMMAND_ENTER);

            AddSendData(cmd);

            while (working) { Thread.Sleep(100); }
        }

        /// <summary>
        /// Create a directory (and all parent direcories if non-existing)
        /// </summary>
        /// <param name="remotePath">The full path of the directory to create</param>
        public void CreateDirectory(string remotePath)
        {
            Connect();

            bool working = true;
            CurrentTimeoutHandler = () => working = false;

            string cmd = String.Format("mkdir -p {0}{1}", remotePath, COMMAND_ENTER);

            AddSendData(cmd);

            while (working) { Thread.Sleep(100); }
        }

        public void Dispose()
        {
            StopConnectionThread();
        }

    }
}
